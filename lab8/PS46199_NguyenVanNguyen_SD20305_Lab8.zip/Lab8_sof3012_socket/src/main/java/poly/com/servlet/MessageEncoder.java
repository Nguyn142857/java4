package poly.com.servlet;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.websocket.EncodeException;
import jakarta.websocket.Encoder;
import jakarta.websocket.EndpointConfig; // Cần import cái này
import poly.com.model.Message;

public class MessageEncoder implements Encoder.Text<Message> {
    
    private static ObjectMapper mapper = new ObjectMapper();

    // --- SỬA: THÊM PHƯƠNG THỨC init ---
    @Override
    public void init(EndpointConfig config) {
        // Phương thức này bắt buộc phải có, dù để trống
    }

    @Override
    public void destroy() {
    }

    @Override
    public String encode(Message message) throws EncodeException {
        try {
            return mapper.writeValueAsString(message);
        } catch (JsonProcessingException e) {
            throw new EncodeException(message, "Unable to encode message", e);
        }
    }
}