package poly.com.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.websocket.DecodeException;
import jakarta.websocket.Decoder;
import jakarta.websocket.EndpointConfig;
import poly.com.model.Message;

import java.io.IOException;

public class MessageDecoder implements Decoder.Text<Message> {

    // Nên để static để dùng chung, đỡ tốn RAM tạo mới liên tục
    private static ObjectMapper mapper = new ObjectMapper();

    @Override
    public void init(EndpointConfig config) {}

    @Override
    public void destroy() {}

    @Override
    public Message decode(String json) throws DecodeException {
        try {
            return mapper.readValue(json, Message.class);
        } catch (IOException e) {
            throw new DecodeException(json, "Unable to decode JSON", e);
        }
    }

    @Override
    public boolean willDecode(String json) {
        // Kiểm tra đơn giản, nếu JSON chứa field "text" thì decode
        return json != null && json.contains("text"); 
    }
}