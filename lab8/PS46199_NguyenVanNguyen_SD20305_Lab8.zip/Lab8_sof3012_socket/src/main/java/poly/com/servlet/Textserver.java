package poly.com.servlet;

import jakarta.websocket.*;
import jakarta.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@ServerEndpoint("/text/chat")
public class Textserver {

    // SỬA: Dùng synchronizedMap để an toàn đa luồng
    private static Map<String, Session> sessions = Collections.synchronizedMap(new HashMap<>());

    private void broadcast(String message) {
        // SỬA: Cần synchronized khi duyệt qua map
        synchronized (sessions) {
            sessions.forEach((id, session) -> {
                if (session.isOpen()) {
                    try {
                        session.getBasicRemote().sendText(message);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    @OnOpen
    public void onOpen(Session session) {
        sessions.put(session.getId(), session);
        broadcast("Someone joined the chat!");
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        broadcast(message);
    }

    @OnClose
    public void onClose(Session session) {
        sessions.remove(session.getId());
        broadcast("Someone left the chat!");
    }

    @OnError
    public void onError(Session session, Throwable throwable) {
        // Log lỗi thay vì cố đóng session có thể đã đóng
        System.out.println("Error in session " + session.getId() + ": " + throwable.getMessage());
    }
}