package poly.com.servlet;

import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import poly.com.model.Message;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@ServerEndpoint(
        value = "/json/chat/{username}",
        encoders = MessageEncoder.class, // Đảm bảo class này đã sửa lỗi init
        decoders = MessageDecoder.class
)
public class ChatserverEndpoint {

    private static Map<String, Session> sessions = Collections.synchronizedMap(new HashMap<>());

    private void broadcast(Message message) {
        synchronized (sessions) {
            for (Session session : sessions.values()) {
                if (session.isOpen()) { // Kiểm tra session còn mở không
                    try {
                        session.getBasicRemote().sendObject(message);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    @OnOpen
    public void onOpen(@PathParam("username") String username, Session session) {
        if (sessions.containsKey(username)) {
            try {
                session.close(new CloseReason(
                        CloseReason.CloseCodes.VIOLATED_POLICY,
                        "Username already exists"
                ));
            } catch (IOException e) {
                e.printStackTrace();
            }
            return;
        }

        sessions.put(username, session);
        session.getUserProperties().put("username", username);

        Message msg = new Message("joined the chat", 0, username, sessions.size());
        broadcast(msg);
    }

    @OnMessage
    public void onMessage(Message message, Session session) {
        String username = (String) session.getUserProperties().get("username");
        message.setSender(username); // Đảm bảo set người gửi là chủ session
        message.setType(2);
        message.setCount(sessions.size());
        broadcast(message);
    }

    @OnClose
    public void onClose(Session session, CloseReason reason) {
        String username = (String) session.getUserProperties().get("username");
        if (username != null) {
            sessions.remove(username);
            Message msg = new Message("left the chat", 1, username, sessions.size());
            broadcast(msg);
        }
    }

    @OnError
    public void onError(Session session, Throwable throwable) {
        System.out.println("Error: " + throwable.getMessage());
    }
}