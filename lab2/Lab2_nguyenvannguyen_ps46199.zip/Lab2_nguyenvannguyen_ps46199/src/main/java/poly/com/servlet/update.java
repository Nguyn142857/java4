package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class update {

	public static void main(String[] args)
	{
		update();
		
	}
	
	
private static void update() {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	EntityManager em = emf.createEntityManager();
try
			{
			em.getTransaction().begin();		
			User entity = em.find(User.class, "nv1213");
			entity.setPassword("ILOVEYOU");
			entity.setAdmin(false);
			entity.setFullname("ĐÀM VĨNH HƯNG");
			em.merge(entity);
			
			em.getTransaction().commit(); 
			System.out.println("Update thanh cong!");
			}
			catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("Update that bai");
			}
			em.close();
			emf.close();
}
}
