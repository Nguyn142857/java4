package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class delete {

	public static void main(String[] args)
	{
		delete();
		
	}
	
	
	
private static void delete() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin(); 

			User entity = em.find(User.class, "nv1214");
			em.remove(entity);

			em.getTransaction().commit();
			System.out.println("Delete thành công!");
		}
		catch (Exception e) {
			em.getTransaction().rollback();
			System.out.println("Delete thất bại!");
		}
		em.close();
		emf.close();
	}
}