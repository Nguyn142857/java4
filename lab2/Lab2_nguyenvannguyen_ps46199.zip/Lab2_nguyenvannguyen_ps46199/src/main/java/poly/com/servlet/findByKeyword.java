package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class findByKeyword {

	public static void main(String[] args)
	{
		findByKeyword("vn1412", "HELLO");
	}
	
	
	private static void findByKeyword(String email, String fullname) {
	    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	    EntityManager em = emf.createEntityManager();
	    try {
	        String jpql = "SELECT o FROM User o WHERE o.Email LIKE ?1 OR o.Fullname LIKE ?2";
	        TypedQuery<User> query = em.createQuery(jpql, User.class);
	        query.setParameter(1, "%" + email + "%");
	        query.setParameter(2, "%" + fullname + "%");
	        
	        List<User> list = query.getResultList();
	        
	        if(list.isEmpty()){
	            System.out.println("Khong tim thay user nao.");
	        } else {
	            for (User user : list) {
	                System.out.println(">>Email: " + user.getEmail());
	                System.out.println(">>Is Admin: " + user.getAdmin());
	            }
	        }
	        
	        System.out.println("Truy van thanh cong!");
	    } catch (Exception e) {
	        System.out.println("Truy van that bai!");
	        e.printStackTrace();
	    }
	    em.close();
	    emf.close();
	}
}