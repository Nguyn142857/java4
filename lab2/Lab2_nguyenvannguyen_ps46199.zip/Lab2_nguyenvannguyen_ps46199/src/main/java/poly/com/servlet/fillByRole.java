package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class fillByRole {

	public static void main(String[] args)
	{
		findByRole(true);
		
	}
	

private static void findByRole(boolean role) {
	// nap 
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
	EntityManager em = emf.createEntityManager();
	try {
		String jpql = "SELECT o FROM User o WHERE o.Admin=:role";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter("role", role);
		List<User> list = query.getResultList();
		for (User user : list) {
			System.out.println(">>Email: " + user.getEmail());
			System.out.println(">>Is Admin: " + user.getAdmin());
		}
		System.out.println("Truy van thanh cong!");
	} catch (Exception e) {
		System.out.println("Truy van loi!");
	}
	em.close();
	emf.close();
}

}
