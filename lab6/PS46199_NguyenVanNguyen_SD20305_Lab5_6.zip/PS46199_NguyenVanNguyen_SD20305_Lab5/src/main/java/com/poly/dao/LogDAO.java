package com.poly.dao;

import com.poly.entity.Log;

public interface LogDAO {
	void create(Log log);
}
