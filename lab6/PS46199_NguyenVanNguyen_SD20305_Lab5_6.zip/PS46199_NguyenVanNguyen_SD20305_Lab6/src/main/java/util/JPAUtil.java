package util;

import jakarta.persistence.*;

public class JPAUtil {
    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("Lab6jav4");

    public static EntityManager getEntityManager(){
        return emf.createEntityManager();
    }
}
