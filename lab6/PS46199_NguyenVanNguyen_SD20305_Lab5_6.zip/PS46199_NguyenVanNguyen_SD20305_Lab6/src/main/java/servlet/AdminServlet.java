package servlet;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({
    "/admin/video",
    "/admin/user",
    "/admin/like",
    "/admin/share"
})

public class AdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String uri = request.getRequestURI();

        if (uri.endsWith("/video")) {
            request.getRequestDispatcher("/admin/video.jsp").forward(request, response);

        } else if (uri.endsWith("/user")) {
            request.getRequestDispatcher("/admin/user.jsp").forward(request, response);

        } else if (uri.endsWith("/like")) {
            request.getRequestDispatcher("/admin/like.jsp").forward(request, response);

        } else if (uri.endsWith("/share")) {
            request.getRequestDispatcher("/admin/share.jsp").forward(request, response);
        }
    }
}