package servlet;

import entity.User;
import dao.UserDAO;
import daoimpl.UserDAOImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    UserDAO dao = new UserDAOImpl();

    // ✅ Cho phép GET (mở form)
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.getRequestDispatcher("/login.jsp")
            .forward(req, resp);
    }

    // ✅ Xử lý POST (submit login)
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String id = req.getParameter("id");
        String pw = req.getParameter("password");

        User user = dao.findById(id);

        if(user == null || !user.getPassword().equals(pw)){
            req.setAttribute("message","Sai tài khoản hoặc mật khẩu!");
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
            return;
        }

        HttpSession session = req.getSession();
        session.setAttribute("user", user);

        String redirect = (String) session.getAttribute("redirectUri");

        if(redirect != null){
            session.removeAttribute("redirectUri");
            resp.sendRedirect(redirect);
        } else {
            resp.sendRedirect(req.getContextPath() + "/page.jsp");
        }
    }
}

