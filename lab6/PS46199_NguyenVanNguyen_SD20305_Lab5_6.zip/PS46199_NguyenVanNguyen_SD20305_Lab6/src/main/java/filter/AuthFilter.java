package filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import entity.User;

@WebFilter(urlPatterns = {
   "/admin/*",
   "/account/change-password",
   "/account/edit-profile",
   "/video/like/*",
   "/video/share/*"
})
public class AuthFilter implements Filter {

    public void doFilter(ServletRequest req, ServletResponse resp,
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        String uri = request.getRequestURI();

        // Chưa login
        if(user == null){
            session.setAttribute("redirectUri", uri);
            response.sendRedirect(request.getContextPath()+"/login.jsp");
            return;
        }

        // Kiểm tra admin
        if(uri.contains("/admin") && !user.isAdmin()){
            response.sendError(403);
            return;
        }

        chain.doFilter(req, resp);
    }
}
