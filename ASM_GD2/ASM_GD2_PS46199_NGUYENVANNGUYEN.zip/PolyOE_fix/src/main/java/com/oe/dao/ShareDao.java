package com.oe.dao;

import java.util.List;
import org.hibernate.Session;
import com.oe.entity.Share;
import com.oe.entity.Video;
import com.oe.util.HibernateUtil;

public class ShareDao extends AbstractDao<Share, Long> {

    public ShareDao() {
        super(Share.class);
    }

    public List<Share> findByVideo(Video video) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                "SELECT s FROM Share s WHERE s.video = :v",
                Share.class)
                .setParameter("v", video)
                .getResultList();
        }
    }
}
