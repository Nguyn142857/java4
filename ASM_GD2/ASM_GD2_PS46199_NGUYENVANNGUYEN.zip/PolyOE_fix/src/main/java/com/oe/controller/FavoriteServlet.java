package com.oe.controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.oe.dao.*;
import com.oe.entity.*;
import com.oe.util.SessionUtil;

@WebServlet("/favorite/*")
public class FavoriteServlet extends HttpServlet {

    private final FavoriteDao favoriteDao = new FavoriteDao();
    private final VideoDao videoDao = new VideoDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        if (path == null) {
            resp.sendError(404);
            return;
        }

        switch (path) {
            case "/list":
                list(req, resp);
                break;

            case "/like":  // GET hợp lý (action nhẹ)
                like(req, resp);
                break;

            default:
                resp.sendError(404);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String path = req.getPathInfo();

        if (path == null) {
            resp.sendError(404);
            return;
        }

        switch (path) {
            case "/unlike":  // Chuyển Unlike sang POST (chuẩn)
                unlike(req, resp);
                break;

            default:
                resp.sendError(404);
        }
        
        
    }

    // ============================
    //  METHOD: LIST FAVORITES
    // ============================
    private void list(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        User user = getLoggedUser(req, resp);
        System.out.println("SESSION USER = " + user);
        if (user == null) return;
        List<Favorite> list = favoriteDao.findByUser(user);

     // In số lượng favorite
     System.out.println(">>> FAVORITE COUNT = " + list.size());

     // In từng video
     for (Favorite f : list) {
         System.out.println(">>> Favorite ID: " + f.getId() 
             + " | VIDEO = " + (f.getVideo() != null ? f.getVideo().getId() : "NULL"));
     }

     req.setAttribute("favorites", list);
     req.getRequestDispatcher("/WEB-INF/views/favorite/favorites.jsp").forward(req, resp);


        req.setAttribute("favorites", favoriteDao.findByUser(user));
        req.getRequestDispatcher("/WEB-INF/views/favorite/favorites.jsp")
            .forward(req, resp);
    }

    // ============================
    //  METHOD: LIKE
    // ============================
    private void like(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        User user = getLoggedUser(req, resp);
        if (user == null) return;

        String videoId = req.getParameter("id");
        Video video = videoDao.findById(videoId);

        if (video == null) {
            resp.sendError(404, "Video not found");
            return;
        }

        // Không tạo trùng Favorite
        if (favoriteDao.findByUserAndVideo(user, video) == null) {
            Favorite f = new Favorite();
            f.setUser(user);
            f.setVideo(video);
            favoriteDao.create(f);
        }

        resp.sendRedirect(req.getContextPath() + "/video/detail?id=" + videoId);
    }

    // ============================
    //  METHOD: UNLIKE (POST)
    // ============================
    private void unlike(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        User user = getLoggedUser(req, resp);
        if (user == null) return;

        String videoId = req.getParameter("id");
        Video video = videoDao.findById(videoId);

        if (video == null) {
            resp.sendError(404, "Video not found");
            return;
        }

        Favorite f = favoriteDao.findByUserAndVideo(user, video);
        if (f != null) {
            favoriteDao.delete(f.getId());
        }

        resp.sendRedirect(req.getContextPath() + "/favorite/list");
    }

    // ============================
    //  HELPER: GET LOGGED USER
    // ============================
    private User getLoggedUser(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        User user = (User) SessionUtil.get(req, "user");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/user/login");
            return null;
        }
        return user;
        
        
    }

}
