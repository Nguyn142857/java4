package com.oe.entity;

import java.util.Date;
import jakarta.persistence.*;

@Entity
@Table(name = "Favorites")
public class Favorite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ----------------------
    // USER
    // ----------------------
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)   // FIXED
    private User user;

    // ----------------------
    // VIDEO
    // ----------------------
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "video_id", nullable = false)  // FIXED
    private Video video;

    // ----------------------
    // DATE → share_date
    // ----------------------
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "share_date")                     // FIXED
    private Date shareDate = new Date();             // rename variable also

    // GETTERS & SETTERS
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Video getVideo() { return video; }
    public void setVideo(Video video) { this.video = video; }

    public Date getShareDate() { return shareDate; }       // FIXED
    public void setShareDate(Date shareDate) { this.shareDate = shareDate; } // FIXED
}
