package com.oe.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.oe.entity.Favorite;
import com.oe.entity.User;
import com.oe.entity.Video;
import com.oe.util.HibernateUtil;

public class FavoriteDao extends AbstractDao<Favorite, Long> {

    public FavoriteDao() {
        super(Favorite.class);
    }

    // -------------------------------------------------------------
    // 1. TÌM FAVORITE THEO USER VÀ VIDEO (JOIN FETCH LOAD VIDEO)
    // -------------------------------------------------------------
    public Favorite findByUserAndVideo(User user, Video video) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            return session.createQuery(
                "SELECT f FROM Favorite f "
              + "JOIN FETCH f.video "
              + "WHERE f.user = :u AND f.video = :v",
                Favorite.class
            )
            .setParameter("u", user)
            .setParameter("v", video)
            .uniqueResultOptional()
            .orElse(null);
        }
    }

    // -------------------------------------------------------------
    // 2. LẤY DANH SÁCH VIDEO USER ĐÃ THÍCH (JOIN FETCH LOAD VIDEO)
    // -------------------------------------------------------------
    public List<Favorite> findByUser(User user) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            return session.createQuery(
                "SELECT f FROM Favorite f "
              + "JOIN FETCH f.video "
              + "WHERE f.user = :u "
              + "ORDER BY f.id DESC",
                Favorite.class
            )
            .setParameter("u", user)
            .getResultList();
        }
    }

    // -------------------------------------------------------------
    // 3. TÌM USER ĐÃ THÍCH 1 VIDEO
    // -------------------------------------------------------------
    public List<User> findUsersByVideo(Video video) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {

            return session.createQuery(
                "SELECT f.user FROM Favorite f WHERE f.video = :v",
                User.class
            )
            .setParameter("v", video)
            .getResultList();
        }
    }

    // -------------------------------------------------------------
    // 4. TẠO FAVORITE (DÙNG HÀM CỦA ABSTRACTDAO)
    // -------------------------------------------------------------
    public Favorite create(Favorite f) {
        return super.create(f);
    }

    // -------------------------------------------------------------
    // 5. XÓA FAVORITE THEO ID (DÙNG HÀM CỦA ABSTRACTDAO)
    // -------------------------------------------------------------
    public void delete(Long id) {
        super.delete(id);
    }
}
