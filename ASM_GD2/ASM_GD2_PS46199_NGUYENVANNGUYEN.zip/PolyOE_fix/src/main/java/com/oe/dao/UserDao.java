package com.oe.dao;

import java.util.List;
import org.hibernate.Session;
import com.oe.entity.User;
import com.oe.util.HibernateUtil;

public class UserDao extends AbstractDao<User, String> {

    public UserDao() {
        super(User.class);
    }

    public User findByEmailAndPassword(String email, String password) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "SELECT u FROM User u WHERE u.email = :email AND u.password = :pw",
                    User.class)
                    .setParameter("email", email)
                    .setParameter("pw", password)
                    .uniqueResult();
        }
    }

    public User findByEmail(String email) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "FROM User u WHERE u.email = :email", User.class)
                    .setParameter("email", email)
                    .uniqueResult();
        }
    }




    public List<User> findAdmins() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery(
                    "SELECT u FROM User u WHERE u.admin = true", User.class)
                    .getResultList();
        }
    }
}
