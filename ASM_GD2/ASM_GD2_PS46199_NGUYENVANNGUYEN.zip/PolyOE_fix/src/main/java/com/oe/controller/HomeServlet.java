package com.oe.controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import com.oe.dao.VideoDao;
import com.oe.entity.Video;

@WebServlet({"/", "/home", "/index"})
public class HomeServlet extends HttpServlet {

    private final VideoDao videoDao = new VideoDao();
    private static final int PAGE_SIZE = 6;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        int page = 1;
        String p = req.getParameter("page");
        if (p != null && p.matches("\\d+")) page = Integer.parseInt(p);

        long total = videoDao.count();
        int totalPages = (int) Math.ceil((double) total / PAGE_SIZE);

        List<Video> videos = videoDao.findPage(page, PAGE_SIZE);

        req.setAttribute("videos", videos);
        req.setAttribute("currentPage", page);
        req.setAttribute("totalPages", totalPages);

        req.getRequestDispatcher("/WEB-INF/views/video/home.jsp").forward(req, resp);
    }
}
