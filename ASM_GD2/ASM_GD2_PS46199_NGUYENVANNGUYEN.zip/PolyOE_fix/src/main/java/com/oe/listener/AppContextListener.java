package com.oe.listener;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import com.oe.util.HibernateUtil;

@WebListener
public class AppContextListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // ép Hibernate khởi tạo sớm
        HibernateUtil.getSessionFactory();
        
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        HibernateUtil.getSessionFactory().close();
    }
    
}
